#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#define N 100000
#define NUM_THREADS 4

struct ThreadData {
    int start;
    int end;
    int count;
};

// Function to check if a number is prime
int is_prime(int num) {
    if (num <= 1) return 0; // 0 and 1 are not prime numbers
    if (num <= 3) return 1; // 2 and 3 are prime numbers
    if (num % 2 == 0 || num % 3 == 0) return 0; // multiples of 2 and 3 are not prime
    
    // Check for prime numbers of form 6k ± 1
    for (int i = 5; i * i <= num; i += 6) {
        if (num % i == 0 || num % (i + 2) == 0)
            return 0;
    }
    return 1; // It is a prime number
}

// Thread function
void* count_primes(void* arg) {
    struct ThreadData* data = (struct ThreadData*)arg;
    data->count = 0;

    // Count prime numbers in the range [start, end)
    for (int i = data->start; i < data->end; i++) {
        if (is_prime(i)) {
            data->count++;
        }
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    struct ThreadData thread_data[NUM_THREADS];
    double exe_time;
    struct timeval start_time, stop_time;

    gettimeofday(&start_time, NULL);

    // Create threads
    int chunk_size = N / NUM_THREADS;
    for (int i = 0; i < NUM_THREADS; i++) {
        thread_data[i].start = i * chunk_size + 1;
        thread_data[i].end = (i == NUM_THREADS - 1) ? N : (i + 1) * chunk_size + 1;
        pthread_create(&threads[i], NULL, count_primes, &thread_data[i]);
    }

    // Join threads and accumulate the total count
    int total_count = 0;
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
        total_count += thread_data[i].count;
    }

    gettimeofday(&stop_time, NULL);
    exe_time = (stop_time.tv_sec + (stop_time.tv_usec / 1000000.0)) - (start_time.tv_sec + (start_time.tv_usec / 1000000.0));

    // Print the results
    printf("Number of prime numbers = %d\n", total_count);
    printf("Execution time = %lf seconds\n", exe_time);

    return 0;
}
