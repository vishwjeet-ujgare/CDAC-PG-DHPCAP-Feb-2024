#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define SIZE 1000

int main() {

    int **matrixA, **matrixB, **result;
    matrixA = (int **)malloc(SIZE * sizeof(int *));
    matrixB = (int **)malloc(SIZE * sizeof(int *));
    result = (int **)malloc(SIZE * sizeof(int *));

    for (int i = 0; i < SIZE; i++) {
        matrixA[i] = (int *)malloc(SIZE * sizeof(int));
        matrixB[i] = (int *)malloc(SIZE * sizeof(int));
        result[i] = (int *)malloc(SIZE * sizeof(int));
    }


    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            matrixA[i][j] = i + j;
            matrixB[i][j] = i * j;
        }
    }


    clock_t start_time = clock();

    //  matrix multiplication
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            result[i][j] = 0;
            for (int k = 0; k < SIZE; k++) {
                result[i][j] += matrixA[i][k] * matrixB[k][j];
            }
        }
    }


    clock_t end_time = clock();

  
    double elapsed_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC * 1000.0;

    // printf("Result matrix:\n");
    // for (int i = 0; i < SIZE; i++) {
    //     for (int j = 0; j < SIZE; j++) {
    //         printf("%d ", result[i][j]);
    //     }
    //     printf("\n");
    // }


    printf("Elapsed time: %.2f milliseconds\n", elapsed_time);


    for (int i = 0; i < SIZE; i++) {
        free(matrixA[i]);
        free(matrixB[i]);
        free(result[i]);
    }
    free(matrixA);
    free(matrixB);
    free(result);

    return 0;
}
