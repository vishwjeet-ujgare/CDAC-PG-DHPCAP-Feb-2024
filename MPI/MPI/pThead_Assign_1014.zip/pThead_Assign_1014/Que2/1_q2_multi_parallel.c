#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> // For time measurement

#define MATRIX_SIZE 1000
#define NUM_THREADS 5

struct ThreadData {
  int **matrix1, **matrix2, **result;
  int start_row, end_row;
};

void* matrix_multiply(void* arg) {
  struct ThreadData* data = (struct ThreadData*)arg;
  int i, j, k;
  for (i = data->start_row; i < data->end_row; i++) {
    for (j = 0; j < MATRIX_SIZE; j++) {
      int sum = 0; // Use a local variable for accumulation
      for (k = 0; k < MATRIX_SIZE; k++) {
        sum += data->matrix1[i][k] * data->matrix2[k][j];
      }
      data->result[i][j] = sum;
    }
  }
  return NULL;
}

int main() {
  int **matrix1, **matrix2, **result;
  matrix1 = (int**)malloc(MATRIX_SIZE * sizeof(int*));
  matrix2 = (int**)malloc(MATRIX_SIZE * sizeof(int*));
  result = (int**)malloc(MATRIX_SIZE * sizeof(int*));
  for (int i = 0; i < MATRIX_SIZE; i++) {
    matrix1[i] = (int*)malloc(MATRIX_SIZE * sizeof(int));
    matrix2[i] = (int*)malloc(MATRIX_SIZE * sizeof(int));
    result[i] = (int*)malloc(MATRIX_SIZE * sizeof(int));
  }

  // Initialize matrices matrix1 and matrix2
  for (int i = 0; i < MATRIX_SIZE; i++) {
    for (int j = 0; j < MATRIX_SIZE; j++) {
      matrix1[i][j] = i + j;
      matrix2[i][j] = i * j;
    }
  }

  pthread_t threads[NUM_THREADS];
  struct ThreadData data[NUM_THREADS];
  int chunk_size = MATRIX_SIZE / NUM_THREADS;

  // Measure start time
  clock_t start_time = clock();

  // Create threads for matrix multiplication
  for (int i = 0; i < NUM_THREADS; i++) {
    data[i].matrix1 = matrix1;
    data[i].matrix2 = matrix2;
    data[i].result = result;
    data[i].start_row = i * chunk_size;
    data[i].end_row = (i == NUM_THREADS - 1) ? MATRIX_SIZE : (i + 1) * chunk_size;
    pthread_create(&threads[i], NULL, matrix_multiply, &data[i]);
  }

  // Wait for all threads to complete
  for (int i = 0; i < NUM_THREADS; i++) {
    pthread_join(threads[i], NULL);
  }

  // Measure end time
  clock_t end_time = clock();

  // Calculate elapsed time in milliseconds
  double elapsed_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC * 1000.0;

  // Print the result matrix (optional)
  // printf("Result matrix:\n");
  // for (int i = 0; i < MATRIX_SIZE; i++) {
  //   for (int j = 0; j < MATRIX_SIZE; j++) {
  //     printf("%d ", result[i][j]);
  //   }
  //   printf("\n");
  // }

  // Print elapsed time
  printf("Elapsed time: %.2f milliseconds\n", elapsed_time);

  // Free allocated memory
  for (int i = 0; i < MATRIX_SIZE; i++) {
    free(matrix1[i]);
    free(matrix2[i]);
    free(result[i]);
  }
  free(matrix1);
  free(matrix2);
  free(result);

  return 0;
}
