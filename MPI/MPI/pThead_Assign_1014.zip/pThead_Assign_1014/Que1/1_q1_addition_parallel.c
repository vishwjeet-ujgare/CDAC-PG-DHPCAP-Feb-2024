#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>  
#define ARRAY_SIZE 10000000
#define NUM_OF_THREADS 20

int *array1; 
int *array2; 
int *result_array; 

void *matrix_addition(void* threadId) {
    long tid = (long)threadId; // Convert thread ID to long
    long localSum = 0; // Local sum initialized to zero
    int chunk_size = ARRAY_SIZE / NUM_OF_THREADS; // Calculate chunk size for each thread
    int start = tid * chunk_size; // Calculate start index for this thread
    int end = (tid + 1) * chunk_size; // Calculate end index for this thread

    // Ensure the last thread processes the remaining elements
    if (tid == NUM_OF_THREADS - 1) {
        end = ARRAY_SIZE;
    }

    // Perform addition for the assigned chunk
    for (int i = start; i < end; i++) {
        result_array[i] = array1[i] + array2[i];
    }

    return NULL;
}

int main() {

    // Allocating  memory for array1 array2 and also for storing result array
    array1 = (int*)malloc(sizeof(int) * ARRAY_SIZE); 
    array2 = (int*)malloc(sizeof(int) * ARRAY_SIZE); 
    result_array = (int*)malloc(sizeof(int) * ARRAY_SIZE); 

    // Initiazing array 1 and array two serially with i value and in result array for now storing 0 to avoid garbage values
    for (int i = 0; i < ARRAY_SIZE; i++) {
        array1[i] = i + 1; 
        array2[i] = i + 1; 
        result_array[i] = 0; 
    }

    // Thread array to hold array of pthread_t type
    pthread_t threads[NUM_OF_THREADS]; 

    // measuring time after addding data and before creating thread
    clock_t start_time = clock();


    // Creating threads
    for (long i = 0; i < NUM_OF_THREADS; i++) {
        // Creating threads with matrix_addition
        pthread_create(&threads[i], NULL, matrix_addition, (void*)i);
    }

    // Joining threads
    // wait for their completion
    for (long i = 0; i < NUM_OF_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }


    // Measure end time
    clock_t end_time = clock();

    // Calculating time in milliseconds
    double elapsed_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC * 1000.0;


    // Printing result array
    for (int i = 0; i < ARRAY_SIZE; i++) {
        // printf("%d ", result_array[i]);
    }


     // Print elapsed time
    printf("\nTime Taken By code : %.2f milliseconds\n", elapsed_time);

    // Free allocated memory
    free(array1);
    free(array2);
    free(result_array);

    return 0;
}

// Time Taken By code : 37.29 milliseconds
// Time Taken By code : 29.91 milliseconds
// Time Taken By code : 22.80 milliseconds
// Time Taken By code : 25.60 milliseconds