#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define N 10000000

int main() {

    int *array = (int *)malloc(sizeof(int) * 3 * N);

   
    int *arrayA = array;
    int *arrayB = arrayA + N;
    int *resultArray = arrayB + N;

  
    for (int i = 0; i < N; i++) {
        arrayA[i] = i + 1;
        arrayB[i] = i + 1;
    }


    clock_t start_time = clock();

    for (int i = 0; i < N; i++) {
        resultArray[i] = arrayA[i] + arrayB[i];
    }


    clock_t end_time = clock();


    double elapsed_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC * 1000.0;

    // Print the resultArray
    printf("Result array:\n");
    for (int i = 0; i < N; i++) {
        // printf("%d ", resultArray[i]);
    }
    printf("\n");


    printf("Elapsed time: %.2f milliseconds\n", elapsed_time);

    free(array);

    return 0;
}

// Elapsed time: 52.08 milliseconds
// Elapsed time: 56.30 milliseconds
// Elapsed time: 51.46 milliseconds
// Elapsed time: 51.08 milliseconds